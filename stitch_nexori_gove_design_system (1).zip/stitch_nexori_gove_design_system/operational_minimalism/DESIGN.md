---
name: Operational Minimalism
colors:
  surface: '#151D2A'
  surface-dim: '#0c141d'
  surface-bright: '#323a44'
  surface-container-lowest: '#070f18'
  surface-container-low: '#141c25'
  surface-container: '#18202a'
  surface-container-high: '#232b34'
  surface-container-highest: '#2d353f'
  on-surface: '#dbe3f0'
  on-surface-variant: '#bbcac6'
  inverse-surface: '#dbe3f0'
  inverse-on-surface: '#29313b'
  outline: '#859491'
  outline-variant: '#3c4947'
  surface-tint: '#50dbcb'
  primary: '#50dbcb'
  on-primary: '#003732'
  primary-container: '#00b3a4'
  on-primary-container: '#003e38'
  inverse-primary: '#006a61'
  secondary: '#b8c3ff'
  on-secondary: '#002388'
  secondary-container: '#0736ba'
  on-secondary-container: '#a1b1ff'
  tertiary: '#ffba3e'
  on-tertiary: '#432c00'
  tertiary-container: '#d49300'
  on-tertiary-container: '#4b3200'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#71f8e7'
  primary-fixed-dim: '#50dbcb'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#005049'
  secondary-fixed: '#dde1ff'
  secondary-fixed-dim: '#b8c3ff'
  on-secondary-fixed: '#001355'
  on-secondary-fixed-variant: '#0736ba'
  tertiary-fixed: '#ffdeae'
  tertiary-fixed-dim: '#ffba3e'
  on-tertiary-fixed: '#281900'
  on-tertiary-fixed-variant: '#604100'
  background: '#0c141d'
  on-background: '#dbe3f0'
  surface-variant: '#2d353f'
  surface-elevated: '#1C2635'
  border-muted: '#2B3648'
  text-primary: '#E8EEF7'
  text-secondary: '#94A3B8'
  critical: '#D64545'
typography:
  display-lg:
    fontFamily: Satoshi
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-base:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-bold:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-caps:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
  stat-lg:
    fontFamily: Satoshi
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.02em
  mono-technical:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 12px
  lg: 16px
  xl: 24px
  xxl: 32px
  gutter: 16px
  margin-desktop: 32px
  sidebar-width: 240px
---

## Brand & Style

The design system embodies **Operational Minimalism**—a high-integrity visual language designed for mission-critical enterprise governance. It rejects the playful, rounded aesthetics of consumer SaaS in favor of an authoritative "Mission Control" experience. The style draws inspiration from the technical sophistication of Palantir Foundry, the surgical clarity of Linear, and the data-rich density of Bloomberg terminals.

The brand personality is **authoritative, calm, and intelligent**. It should evoke a sense of total operational control and executive-grade maturity. Visuals are disciplined and structured, prioritizing information hierarchy and rapid decision-making over decorative flair.

**Key Design Principles:**
- **Precision over Playfulness:** Use sharp corners, hairline borders, and monospaced technical data.
- **Data as Hero:** Maximize information density without clutter using a strict 4px baseline grid.
- **Controlled Motion:** Transitions are fast (150ms) and functional, providing immediate feedback for complex workflows.
- **Dark-Mode First:** A deep, low-glare obsidian environment designed for high-concentration governance tasks.

## Colors

Color is used as a **semantic layer** rather than decoration. The palette is dominated by a range of obsidian and slate tones to establish physical layering through lightness shifts rather than shadows.

- **Primary Accent (Controlled Teal):** Signals "normal operations," active navigation, and validated system states.
- **Neutral Foundation:** The base (`#0F1720`) and surfaces (`#151D2A`, `#1C2635`) create a tiered hierarchy of containers and overlays.
- **Risk Indicators:** Warning Amber (`#E8A317`) and Critical Crimson (`#D64545`) are reserved exclusively for governance risks, policy breaches, and emergency controls.
- **Borders:** A universal hairline border (`#2B3648`) defines the layout grid, maintaining structure without visual noise.

## Typography

The typographic system balances executive polish with technical utility. 

- **Satoshi (Display):** Used for high-level KPIs and primary headers to project authority and structural strength.
- **Inter (Interface):** The workhorse for all body text, labels, and standard headers. It ensures high legibility across dense data sets.
- **Geist (Technical):** Reserved for monospaced data, including cryptographic hashes, regulatory codes, timestamps, and AI model IDs.

**Type Rules:**
- **All-Caps Labels:** Small labels and micro-text must use `label-caps` (Geist) with expanded tracking for readability.
- **Data Alignment:** All numeric values in tables should utilize tabular figures to ensure columns align vertically for rapid scanning.

## Layout & Spacing

This system utilizes a **Structured Fluid Grid** model. The primary layout consists of a fixed-width left navigation sidebar (240px) and a flexible, modular workspace that expands to a maximum of 1440px to prevent visual fragmentation on ultra-wide displays.

**Spacing Rhythm:**
- A strict **4px baseline grid** governs all elements.
- **Density:** We prioritize compactness. Use `12px` (md) for internal component spacing and `16px` (lg) for container padding. 
- **Grids:** Use a 12-column grid for dashboard layouts. Widgets should span 3, 4, 6, or 12 columns depending on data complexity.

**Responsiveness:**
- **Desktop (1280px+):** Full multi-panel view with persistent sidebar and inspector panels.
- **Tablet (768px-1024px):** Sidebar collapses to icons; table columns truncate based on priority.
- **Mobile (<768px):** Single column stack; critical status indicators and "Emergency Kill Switch" remain accessible via a fixed footer or header bar.

## Elevation & Depth

Depth is conveyed through **Tonal Layering** and **Hairline Outlines** rather than soft shadows. This maintains the "Mission Control" aesthetic of a flat, embedded system.

- **Layer 0 (Background):** `#0F1720` - The base canvas.
- **Layer 1 (Surface):** `#151D2A` - Cards, table bodies, and primary workspace containers.
- **Layer 2 (Elevated):** `#1C2635` - Overlays, context menus, tooltips, and active hover states.
- **Outlines:** Every surface must be framed by a `1px` solid border (`#2B3648`). Shadows are avoided except for high-z-index modal overlays, which use a subtle, non-diffused `#000000` shadow at 40% opacity.

## Shapes

The shape language is **Soft-edged but disciplined**. Roundedness is kept to a minimum to maintain a professional, technical feel.

- **Standard Elements:** 4px (`rounded-sm`) for buttons, inputs, and small widgets.
- **Containers:** 6px (Default) for cards and main workspace panels.
- **Interactive Pills:** Use `rounded-full` only for status badges and pills where maximum distinction from the square grid is required.

## Components

### Enterprise Table System
- **Density:** Locked row height of 36px.
- **Styling:** Hairline horizontal separators only. Use `#151D2A` for row backgrounds.
- **Interaction:** Hovering triggers a background shift to `#1C2635`.
- **Content:** Status icons must be leading; numeric/ID data must use Geist Mono.

### Governance Timeline
- **Visuals:** A vertical 1.5px track (`#2B3648`) with circular event nodes.
- **Nodes:** Colored semantically (Teal = Approval, Amber = Pending, Crimson = Breach).
- **Metadata:** Packed tightly; includes user avatar, Geist-font hash, and DORA-standard timestamp.

### Risk Visualization & Heatmaps
- **Gauges:** Use horizontal bar gauges rather than radial charts.
- **Heatmaps:** Utilize fixed-size squares with color intensity based on the Warning/Critical palette. Avoid gradients.

### Buttons & Controls
- **Primary:** Solid Controlled Teal (`#00B3A4`) with dark text.
- **Ghost:** Transparent background with `#2B3648` border.
- **Emergency Kill Switch:** Heavy Crimson (`#D64545`) background, uppercase bold text, specific to AI Control modules.

### Operational Alerts
- **Banners:** Non-floating, pinned to the top of containers.
- **States:** Backgrounds use 12% opacity of the semantic color with a 1px solid border of the full-strength color.